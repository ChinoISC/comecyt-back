package com.example.proyecto.demo.Entity;

import jakarta.persistence.*;
import lombok.*;
import java.util.Set;
import java.util.HashSet;

@Entity
@Table(name = "auth_users", indexes = {
        @Index(name = "idx_auth_users_username", columnList = "username", unique = true),
        @Index(name = "idx_auth_users_email", columnList = "email", unique = true)
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthUser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 80, unique = true)
    private String username;         // o usar email como username

    @Column(nullable = false, length = 180, unique = true)
    private String email;

    @Column(nullable = false, length = 72) // BCrypt ~60
    private String passwordHash;

    @Column(nullable = false)
    private boolean enabled = true;

    @Column(nullable = false)
    private boolean locked = false;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "auth_user_roles", joinColumns = @JoinColumn(name = "auth_user_id"))
    @Column(name = "role", length = 40)
    private Set<String> roles = new HashSet<>();

    @OneToOne(mappedBy = "authUser", cascade = CascadeType.ALL, fetch = FetchType.LAZY, optional = true)
    private Usuario usuario;
}
