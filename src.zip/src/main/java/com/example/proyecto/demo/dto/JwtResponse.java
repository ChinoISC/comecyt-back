package com.example.proyecto.demo.dto;


public record JwtResponse(String token) {}